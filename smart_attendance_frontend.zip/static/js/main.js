console.log('Frontend loaded');
